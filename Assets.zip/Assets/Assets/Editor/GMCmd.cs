using Codice.Client.BaseCommands;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.VersionControl;
using System;
using Unity.VisualScripting;

namespace jenshin
{
    public class GMCmd
    {
        [MenuItem("CMCmd/��ȡ����")]
        public static void ReadTable()
        {
            PackageTable_SO packageTable = Resources.Load<PackageTable_SO>("ScriptableObjects/PackageData/PackageTable");

            foreach(PackageTableItem packageItem in packageTable.dataList)
            {
                Debug.Log(string.Format("��id��:{0},��name��{1}", packageItem.id, packageItem.name));
            }
        }

        [MenuItem("CMCmd/����������������")]

        public static void CreateLocalPackageData()
        {
            //��������
            PackageLocalData.instance.items = new List<PackageLocalItem>();

            for (int i = 1; i < 9; i++)
            {
                PackageLocalItem packageLocalItem = new()
                {
                    uid = Guid.NewGuid().ToString(),
                    id = i,
                    number = i,
                    level = i,
                    isNew = i % 2 == 1
                };
                PackageLocalData.instance.items.Add(packageLocalItem);
            }

            PackageLocalData.instance.SavePackage();
        }

        [MenuItem("CMCmd/��ȡ������������")]

        public static void ReadLocalPackageData()
        {
            List<PackageLocalItem> readItem = PackageLocalData.instance.LoadPackage();

            foreach (PackageLocalItem item in readItem)
            {
                Debug.Log(item);
            }
        }

        [MenuItem("CMCmd/�򿪱���")]

        public static void OpenPackagePanel()
        {
            UIManager.instance.OpenPanel(UIConst.packagePanel);

            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
        }
    }
}
