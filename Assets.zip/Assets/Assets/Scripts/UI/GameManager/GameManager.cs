using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class GameManager : MonoBehaviour
    {
        private PackageTable_SO packageTable;

        private static GameManager _instance;
        
        public static GameManager instance
        {
            get
            {
                return _instance;
            }
        }

        private void Awake()
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private void Start()
        {
            //�������
            //PackageLocalData.instance.ClearAll();
        }

        public PackageTable_SO GetPackageTable()
        {
            if(packageTable==null)
            {
                packageTable = Resources.Load<PackageTable_SO>("ScriptableObjects/PackageData/PackageTable");
            }
            return packageTable;
        }

        public List<PackageLocalItem> GetPackageLocalData()
        {
            return PackageLocalData.instance.LoadPackage();
        }

        public PackageTableItem GetPackageItemById(int id)
        {
            List<PackageTableItem> packageDataList = GetPackageTable().dataList;

            foreach(PackageTableItem item in packageDataList)
            {
                if (item.id == id)
                {
                    return item;
                }
            }

            return null;
        }

        public PackageLocalItem GetPackageLocalItemByUId(string uid)
        {
            List<PackageLocalItem> packageDataList = GetPackageLocalData();
            foreach (PackageLocalItem item in packageDataList)
            {
                if (item.uid == uid)
                {
                    return item;
                }
            }
            return null;
        }

        public List<PackageLocalItem> GetSortPackageLocalData()
        {
            List<PackageLocalItem> localItem = PackageLocalData.instance.LoadPackage();

            localItem.Sort(new PackageItemComparer());

            return localItem;
        }

        public void DeletePackageItems(List<string> uids)
        {
            foreach(string uid in uids)
            {
                DeletePackageItem(uid, false);
            }

            PackageLocalData.instance.SavePackage();
        }

        public void DeletePackageItem(string uid, bool needSave = true)
        {
            PackageLocalItem packageLocalItem = GetPackageLocalItemByUId(uid);

            if(packageLocalItem==null)
            {
                return;
            }

            PackageLocalData.instance.items.Remove(packageLocalItem);

            if(needSave)
            {
                PackageLocalData.instance.SavePackage();
            }
        }
    }

    public class PackageItemComparer:IComparer<PackageLocalItem>
    {
        public int Compare(PackageLocalItem a,PackageLocalItem b)
        {
            PackageTableItem x = GameManager.instance.GetPackageItemById(a.id);
            PackageTableItem y = GameManager.instance.GetPackageItemById(b.id);

            int starComparison = y.star.CompareTo(x.star);

            if(starComparison==0)
            {
                int idComparison = y.id.CompareTo(x.id);

                if(idComparison==0)
                {
                    return b.level.CompareTo(a.level);
                }

                return idComparison;
            }

            return starComparison;
        }

        
    }
}
