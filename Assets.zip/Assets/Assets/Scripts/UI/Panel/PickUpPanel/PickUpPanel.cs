using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.Animations;

namespace jenshin
{
    public class PickupPanel : BasePanel
    {
        // UI�������
        private Transform UIBackground;
        private Transform UIScrollView;

        // Ԥ�Ƽ�����Ӧ���packageUIItemPrefab��
        public GameObject pickupUIItemPrefab;

        // �����ֵ䣺UID -> PickupCell
        private Dictionary<string, PickUpCell> uidToCellDict = new Dictionary<string, PickUpCell>();

        //private PlayerInput input;

        private int currentCellIndex = 0;

        // ѡ�е�UID
        private string _chooseUid;
        public string chooseUid
        {
            get
            {
                return _chooseUid;
            }
            set
            {
                if (_chooseUid == value) return;

                _chooseUid = value;

                // ˢ��ѡ������ʽ
                RefreshCellSelectedState();
            }
        }

        override protected void Awake()
        {
            base.Awake();

            InitUI();

            _chooseUid = "";
        }

        //��������ص�
        private void OnPickUpSelect(InputAction.CallbackContext context)
        {
            Debug.Log("����ѡ�񽻻�");

            float scrollValue = Player.Input.interactActions.Select.ReadValue<float>();

            if(currentCellIndex >= 0 && currentCellIndex < InteractLocalData.instance.interactables.Count)
            {
                if (scrollValue > 0 && currentCellIndex > 0)
                {
                    //uidToCellDict[chooseUid].UISelect.GetComponent<Animator>().SetTrigger("Out");
                    currentCellIndex--;
                    //uidToCellDict[chooseUid].UISelect.GetComponent<Animator>().SetTrigger("In");
                }
                else if (scrollValue < 0 && currentCellIndex < InteractLocalData.instance.interactables.Count - 1)
                {
                    //uidToCellDict[chooseUid].UISelect.GetComponent<Animator>().SetTrigger("Out");
                    currentCellIndex++;
                    //uidToCellDict[chooseUid].UISelect.GetComponent<Animator>().SetTrigger("Out");
                }

                chooseUid = InteractLocalData.instance.interactables[currentCellIndex].Uid;
            }
        }

        //ȷ��ʰȡ
        private void OnConfirmInteract(InputAction.CallbackContext context)
        {
            Debug.Log("ȷ��ʰȡ");

            InteractLocalData.instance.interactables[currentCellIndex].OnInteract();
            InteractLocalData.instance.RemoveInteractables(InteractLocalData.instance.interactables[currentCellIndex]);

            RefreshUI();

            if(InteractLocalData.instance.interactables==null||InteractLocalData.instance.interactables.Count==0)
            {
                UIManager.instance.ClosePanel(UIConst.pickUpPanel);
            }
        }

        private void OnInteractDataChanged()
        {
            if (InteractLocalData.instance.interactables != null && InteractLocalData.instance.interactables.Count > 0)
            {
                RefreshUI();
                currentCellIndex = 0;
                _chooseUid = InteractLocalData.instance.interactables[0].Uid;
                RefreshCellSelectedStateWithoutAni();
            }
        }

        private void Start()
        {
            //����Ĭ��ѡ��
            _chooseUid = InteractLocalData.instance.interactables[0].Uid;
            //��ʼˢ��UI
            RefreshUI();

            InteractLocalData.instance.OnInteractablesChanged += OnInteractDataChanged;

            Player.Input.interactActions.Select.performed += OnPickUpSelect;

            Player.Input.interactActions.interaction.performed += OnConfirmInteract;
        }

        public override void ClosePanel()
        {
            base.ClosePanel();

            InteractLocalData.instance.OnInteractablesChanged -= OnInteractDataChanged;

            Player.Input.interactActions.Select.performed -= OnPickUpSelect;

            Player.Input.interactActions.interaction.performed -= OnConfirmInteract;
        }

        private void InitUI()
        {
            InitUIName();
        }

        public void RefreshUI()
        {
            RefreshScroll();
        }

        private void RefreshScroll()
        {
            RectTransform scrollContent = UIScrollView.GetComponent<ScrollRect>().content;

            for (int i = 0; i < scrollContent.childCount; i++)
            {
                Destroy(scrollContent.GetChild(i).gameObject);
            }

            uidToCellDict.Clear();

            foreach (BaseInteractData data in InteractLocalData.instance.interactables)
            {
                Transform pickupUIItem = Instantiate(pickupUIItemPrefab.transform, scrollContent) as Transform;
                PickUpCell pickupCell = pickupUIItem.GetComponent<PickUpCell>();

                RegisterCell(data.Uid, pickupCell);
                pickupCell.Refresh(data, this);
            }
        }

        private void RefreshCellSelectedState()
        {
            RectTransform scrollContent = UIScrollView.GetComponent<ScrollRect>().content;
            foreach (Transform cell in scrollContent)
            {
                PickUpCell pickupCell = cell.GetComponent<PickUpCell>();
                pickupCell.RefreshSelectedState();
            }
        }

        private void RefreshCellSelectedStateWithoutAni()
        {
            RectTransform scrollContent = UIScrollView.GetComponent<ScrollRect>().content;
            foreach (Transform cell in scrollContent)
            {
                PickUpCell pickupCell = cell.GetComponent<PickUpCell>();
                pickupCell.RefreshSelectedStateWithoutAni();
            }
        }

        private BaseInteractData GetInteractDataByUid(string uid)
        {
            foreach (BaseInteractData data in InteractLocalData.instance.interactables)
            {
                if (data.Uid == uid)
                {
                    return data;
                }
            }
            return null;
        }

        // ����ӿڣ����½��������б�����InteractManager���ã�
        public void UpdateInteractData(List<BaseInteractData> newDataList)
        {
            InteractLocalData.instance.interactables.Clear();
            if (newDataList != null)
            {
                InteractLocalData.instance.interactables.AddRange(newDataList);
            }
            RefreshUI();
        }

        // ����ӿڣ��л�ѡ������ֿ��ƣ�
        public void SwitchSelectedIndex(int targetIndex)
        {
            if (InteractLocalData.instance.interactables.Count == 0 || targetIndex < 0 || targetIndex >= InteractLocalData.instance.interactables.Count)
            {
                return;
            }
            chooseUid = InteractLocalData.instance.interactables[targetIndex].Uid;
        }


        // ע��Cell���������RegisterCell��
        public void RegisterCell(string uid, PickUpCell cell)
        {
            if (!uidToCellDict.ContainsKey(uid))
            {
                uidToCellDict.Add(uid, cell);
            }
        }

        // ע��Cell���������UnregisterCell��
        public void UnregisterCell(string uid)
        {
            if (uidToCellDict.ContainsKey(uid))
            {
                uidToCellDict.Remove(uid);
            }
        }

        // ����Cell���������GetCellByUid��
        public PickUpCell GetCellByUid(string uid)
        {
            if (uidToCellDict.TryGetValue(uid, out PickUpCell cell))
            {
                return cell;
            }
            return null;
        }

        private void InitUIName()
        {
            UIBackground = transform.Find("Background");
            UIScrollView = transform.Find("Scroll View");
        }
    }
}