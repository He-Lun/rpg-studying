using UnityEngine;
using UnityEngine.UI;

namespace jenshin
{
    public class PickUpCell : MonoBehaviour
    {
        // UI�������Ӧ���PackageCell��
        private Transform UIBackground;
        private Transform UINameText;
        public Transform UISelect;

        // ��ǰCell�󶨵�����
        private BaseInteractData currentData;
        private PickupPanel uiParent;

        private void Awake()
        {
            // ��ʼ��Cell�ڲ�UI
            InitCellUIName();

            InitClick();
        }

        // ��ʼ��Cell��UI���
        private void InitCellUIName()
        {
            UISelect = transform.Find("Select");
            UIBackground = transform.Find("Background");
            UINameText = transform.Find("Name");

            UISelect.gameObject.SetActive(false);
        }

        private void InitClick()
        {
            // �󶨵���¼�
            //GetComponent<Button>().onClick.AddListener(OnClickCell);
        }

        // ˢ��Cell
        public void Refresh(BaseInteractData data, PickupPanel panel)
        {
            currentData = data;
            uiParent = panel;

            if (data == null)
            {
                gameObject.SetActive(false);
                return;
            }

            gameObject.SetActive(true);

            // ˢ���ı�
            UINameText.GetComponent<Text>().text = data.Name.ToString();

            RefreshSelectedStateWithoutAni();
        }

        public void RefreshSelectedStateWithoutAni()
        {
            bool isSelected = uiParent.chooseUid == currentData.Uid;

            if (isSelected)
            {
                UISelect.gameObject.SetActive(true);
            }
            else
            {
                UISelect.gameObject.SetActive(false);
            }
        }

        // ˢ��ѡ��״̬
        public void RefreshSelectedState()
        {
            bool isSelected = uiParent.chooseUid == currentData.Uid;

            if(isSelected)
            {
                UISelect.gameObject.SetActive(true);
                UISelect.GetComponent<Animator>().SetTrigger("In");
            }
            else
            {
                UISelect.gameObject.SetActive(false);
            }
        }

        // Cell����¼�
        private void OnClickCell()
        {
            if (uiParent != null && currentData != null)
            {
                uiParent.chooseUid = currentData.Uid;
                print($">>>>> ѡ�н����{currentData.Name}");
            }
        }

        //���ö���

    }
}