using JetBrains.Annotations;
using NUnit.Framework.Internal;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

namespace jenshin
{
    public class PackageDetail : MonoBehaviour
    {
        private Transform UIStars;
        private Transform UIDescription;
        private Transform UIIcon;
        private Transform UITitle;
        private Transform UILevelText;
        private Transform UISkillDescription;

        private PackageLocalItem packageLocalItem;
        private PackageTableItem packageTableItem;
        private PackagePanel uiParent;

        private void Awake()
        {
            InitUIName();
        }

        private void InitUIName()
        {
            UIStars = transform.Find("Center/Stars");
            UIDescription = transform.Find("Center/Description");
            UIIcon = transform.Find("Center/Icon");
            UITitle = transform.Find("Top/Title");
            UILevelText = transform.Find("Bottom/LevelPanel/Level");
            UISkillDescription = transform.Find("Bottom/Description");
        }

        public void Refresh(PackageLocalItem packageLocalItem, PackagePanel parent)
        {
            this.packageLocalItem = packageLocalItem;
            this.uiParent = parent;
            this.packageTableItem = GameManager.instance.GetPackageItemById(packageLocalItem.id);

            //��������
            UITitle.GetComponent<Text>().text = this.packageTableItem.name;
            //�ȼ�
            UILevelText.GetComponent<Text>().text = string.Format("Lv.{0}/40", this.packageLocalItem.level.ToString());
            //�������
            UIDescription.GetComponent<Text>().text = this.packageTableItem.description;
            //��ϸ����
            UISkillDescription.GetComponent<Text>().text = this.packageTableItem.skillDescription;
            //ͼƬ����
            Texture2D t = (Texture2D)Resources.Load(this.packageTableItem.imagePath);
            Sprite temp = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0, 0));
            UIIcon.GetComponent<Image>().sprite = temp;
            //�Ǽ�����
            RefreshStars();
        }

        public void RefreshStars()
        {
            for (int i = 0; i < UIStars.childCount; i++)
            {
                Transform star = UIStars.GetChild(i);

                if(this.packageTableItem.star>i)
                {
                    star.gameObject.SetActive(true);
                }
                else
                {
                    star.gameObject.SetActive(false);
                }
            }
        }
    }
}
