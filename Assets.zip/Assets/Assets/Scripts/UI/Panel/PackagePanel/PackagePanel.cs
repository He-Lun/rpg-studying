using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace jenshin
{
    public enum PackageMode
    {
        normal,
        delete,
        sort,
    }

    public class PackagePanel : BasePanel
    {
        private Transform UIMenu;
        private Transform UIMenuWeapon;
        private Transform UIMenuFood;
        private Transform UITabName;
        private Transform UICloseBtn;
        private Transform UICenter;
        private Transform UIScrollView;
        private Transform UIDetailPanel;
        private Transform UILeftBtn;
        private Transform UIRightBtn;
        private Transform UIDeletePanel;
        private Transform UIDeleteBackBtn;
        private Transform UIDeleteInfoText;
        private Transform UIDeleteConfirmBtn;
        private Transform UIBottomMenus;
        private Transform UIDeleteBtn;
        private Transform UIDetailBtn;

        public GameObject packageUIItemPrefab;

        public List<string> deleteChooseUid;

        public PackageMode currentMode = PackageMode.normal;

        // �����ֵ䣨˽�У���ͨ���ӿڷ��ʣ�
        private Dictionary<string, PackageCell> uidToCellDict = new Dictionary<string, PackageCell>();

        private string _chooseUid;
        public string chooseUid
        {
            get
            {
                return _chooseUid;
            }
            set
            {
                _chooseUid = value;

                //�»�ñ�ʶ���鿴����ʧ
                PackageLocalItem localItem = GameManager.instance.GetPackageLocalItemByUId(_chooseUid);
                if (localItem != null && localItem.isNew)
                {
                    localItem.isNew = false;
                    PackageLocalData.instance.SavePackage();

                    uidToCellDict[_chooseUid].Refresh(localItem, this);
                }

                RefreshDetail();
            }
        }

        override protected void Awake()
        {
            base.Awake();

            InitUI();

            if (UIDetailPanel != null)
            {
                UIDetailPanel.gameObject.SetActive(false);
            }
            // ���ѡ�е�UID���������ѡ��״̬
            _chooseUid = "";
        }

        private void Start()
        {
            RefreshUI();
        }

        public override void OpenPanel(string name)
        {
            base.OpenPanel(name);

            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;

            PackageReusableData.instance.isOpenPackage = true;
        }

        public override void ClosePanel()
        {
            base.ClosePanel();

            Cursor.visible = false;
            Cursor.lockState = CursorLockMode.Locked;

            PackageReusableData.instance.isOpenPackage = false;
        }

        private void InitUI()
        {
            InitUIName();

            InitClick();
        }

        public void RefreshUI()
        {
            UIDetailPanel.gameObject.SetActive(false);
            // ���ѡ�е�UID������ˢ�º����ѡ��״̬������������Զ���ʾ
            _chooseUid = "";

            RefreshScroll();
        }

        private void RefreshDetail()
        {
            PackageLocalItem localItem = GameManager.instance.GetPackageLocalItemByUId(_chooseUid);

            if (localItem == null)
            {
                UIDetailPanel.gameObject.SetActive(false);
                return;
            }

            // ��Ʒ��Чʱ����ʾ��ˢ������
            UIDetailPanel.gameObject.SetActive(true);

            UIDetailPanel.GetComponent<PackageDetail>().Refresh(localItem, this);
        }

        private void RefreshScroll()
        {
            RectTransform scrollContent = UIScrollView.GetComponent<ScrollRect>().content;

            for (int i = 0; i < scrollContent.childCount; i++)
            {
                Destroy(scrollContent.GetChild(i).gameObject);
            }
            
            foreach(PackageLocalItem localData in GameManager.instance.GetSortPackageLocalData())
            {
                Transform packageUIItem = Instantiate(packageUIItemPrefab.transform, scrollContent) as Transform;

                PackageCell packageCell = packageUIItem.GetComponent<PackageCell>();

                packageCell.Refresh(localData, this);
            }
            
        }

        //����ɾ��ѡ����
        public void AddChooseDeleteUid(string uid)
        {
            this.deleteChooseUid ??= new List<string>();

            if(!this.deleteChooseUid.Contains(uid))
            {
                this.deleteChooseUid.Add(uid);
            }
            else
            {
                this.deleteChooseUid.Remove(uid);
            }
            RefreshDeletePanel();
        }

        private void RefreshDeletePanel()
        {
            RectTransform scrollCotent = UIScrollView.GetComponent<ScrollRect>().content;

            foreach(Transform cell in scrollCotent)
            {
                PackageCell packageCell = cell.GetComponent<PackageCell>();

                packageCell.RefreshDeleteState();
            }
        }

        // �����ṩע��ӿ�
        public void RegisterCell(string uid, PackageCell cell)
        {
            if (!uidToCellDict.ContainsKey(uid))
            {
                uidToCellDict.Add(uid, cell);
            }
        }

        // �����ṩע���ӿ�
        public void UnregisterCell(string uid)
        {
            if (uidToCellDict.ContainsKey(uid))
            {
                uidToCellDict.Remove(uid);
            }
        }

        // O(1)����Cell
        public PackageCell GetCellByUid(string uid)
        {
            if (uidToCellDict.TryGetValue(uid, out PackageCell cell))
            {
                return cell;
            }
            return null;
        }


        private void InitUIName()
        {
            UIMenu = transform.Find("TopCenter/Menu");
            UIMenuWeapon = transform.Find("TopCenter/Menu/Weapon");
            UIMenuFood = transform.Find("TopCenter/Menu/Food");
            UITabName = transform.Find("Lefttop/PackageText");
            UICloseBtn = transform.Find("Righttop/ExitImage");
            UICenter = transform.Find("Center");
            UIScrollView = transform.Find("Center/scrollView");
            UIDetailPanel = transform.Find("Center/DetailedPanel");
            UILeftBtn = transform.Find("Left/Arrow");
            UIRightBtn = transform.Find("Right/Arrow");

            UIDeletePanel = transform.Find("Bottom/DeletePanel");
            UIDeleteBackBtn = transform.Find("Bottom/DeletePanel/Back");
            UIDeleteInfoText = transform.Find("Bottom/DeletePanel/InfoText");
            UIDeleteConfirmBtn = transform.Find("Bottom/DeletePanel/Confirm");
            UIBottomMenus = transform.Find("Bottom/BottomMenus");
            UIDeleteBtn = transform.Find("Bottom/BottomMenus/DeleteButton");
            UIDetailBtn = transform.Find("Bottom/BottomMenus/DetailButton");

            UIDeletePanel.gameObject.SetActive(false);
            UIBottomMenus.gameObject.SetActive(true);
        }

        protected void InitClick()
        {
            UIMenuWeapon.GetComponent<Button>().onClick.AddListener(OnClickWeapon);
            UIMenuFood.GetComponent<Button>().onClick.AddListener(OnClickFood);
            UICloseBtn.GetComponent<Button>().onClick.AddListener(OnClickClose);
            UILeftBtn.GetComponent<Button>().onClick.AddListener(OnClickLeft);
            UIRightBtn.GetComponent<Button>().onClick.AddListener(OnClickRight);

            UIDeleteBackBtn.GetComponent<Button>().onClick.AddListener(OnDeleteBack);
            UIDeleteConfirmBtn.GetComponent<Button>().onClick.AddListener(OnDeleteConfirm);
            UIDeleteBtn.GetComponent<Button>().onClick.AddListener(OnDelete);
            UIDetailBtn.GetComponent<Button>().onClick.AddListener(OnDetail);
        }

        private void OnClickWeapon()
        {
            print(">>>>> OnClickWeapon");
        }

        private void OnClickFood()
        {
            print(">>>>> OnClickFood");
        }

        private void OnClickClose()
        {
            print(">>>>> OnClickClose");
            UIManager.instance.ClosePanel(UIConst.packagePanel);
        }

        private void OnClickLeft()
        {
            print(">>>>> OnClickLeft");
        }

        private void OnClickRight()
        {
            print(">>>>> OnClickRight");
        }

        private void OnDeleteBack()
        {
            print(">>>>> onDeleteBack");

            currentMode = PackageMode.normal;

            UIDeletePanel.gameObject.SetActive(false);

            deleteChooseUid = new List<string>();

            RefreshDeletePanel();
        }

        private void OnDeleteConfirm()
        {
            print(">>>>> OnDeleteConfirm");

            if (this.deleteChooseUid == null || this.deleteChooseUid.Count == 0)
            {
                return;
            }

            GameManager.instance.DeletePackageItems(this.deleteChooseUid);

            RefreshUI();
        }

        private void OnDelete()
        {
            print(">>>>> OnDelete");

            currentMode = PackageMode.delete;

            UIDeletePanel.gameObject.SetActive(true);
        }

        private void OnDetail()
        {
            print(">>>>> OnDetail");
        }
    }
}
