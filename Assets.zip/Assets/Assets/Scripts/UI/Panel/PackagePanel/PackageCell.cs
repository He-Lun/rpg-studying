using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using static Cinemachine.DocumentationSortingAttribute;

namespace jenshin
{
    public class PackageCell : MonoBehaviour,IPointerEnterHandler,IPointerExitHandler,IPointerClickHandler
    {
        private Transform UIIcon;
        private Transform UIHead;
        private Transform UINew;
        private Transform UISelect;
        private Transform UILevel;
        private Transform UIStars;
        private Transform UIDeleteSelect;

        private PackageLocalItem packageLocalData;
        private PackageTableItem packageTableItem;
        private PackagePanel uiParent;

        private Transform UISelectAni;
        private Transform UIMouseOverAni;

        public string CurrentUid { get; private set; } // ��¶UID���ⲿ����

        private void Awake()
        {
            InitUIName();
        }

        private void InitUIName()
        {
            UIIcon = transform.Find("Top/Icon");
            UIHead = transform.Find("Top/Character");
            UINew = transform.Find("Top/New");
            UILevel = transform.Find("Bottom/LevelText");
            UIStars = transform.Find("Bottom/Stars");
            UISelect = transform.Find("Selected");
            UIDeleteSelect = transform.Find("DeleteSelected");
            UISelectAni = transform.Find("SelectAni");
            UIMouseOverAni = transform.Find("MouseOverAni");

            UIDeleteSelect.gameObject.SetActive(false);
            UISelectAni.gameObject.SetActive(false);
            UIMouseOverAni.gameObject.SetActive(false);
        }

        public void Refresh(PackageLocalItem packageLocalData, PackagePanel uiParent)
        {
            // ���ݳ�ʼ��
            this.packageLocalData = packageLocalData;
            this.packageTableItem = GameManager.instance.GetPackageItemById(packageLocalData.id);
            this.uiParent = uiParent;
            this.CurrentUid = packageLocalData.uid;

            // ���ģ�������Panelע���Լ�
            uiParent.RegisterCell(this.CurrentUid, this);

            // �ȼ���Ϣ
            UILevel.GetComponent<Text>().text = "Lv." + this.packageLocalData.level.ToString();
            // �Ƿ����»�ã�
            UINew.gameObject.SetActive(this.packageLocalData.isNew);
            // ��Ʒ��ͼƬ
            Texture2D t = (Texture2D)Resources.Load(this.packageTableItem.imagePath);
            Sprite temp = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0, 0));
            UIIcon.GetComponent<Image>().sprite = temp;
            UIHead.gameObject.SetActive(false);
            // ˢ���Ǽ�
            RefreshStars();
        }

        // ��������������ʱ����ע������ֹ�ڴ�й©��
        private void OnDestroy()
        {
            if (uiParent != null && !string.IsNullOrEmpty(CurrentUid))
            {
                uiParent.UnregisterCell(CurrentUid);
            }
        }

        public void RefreshStars()
        {
            for (int i = 0; i < UIStars.childCount; i++)
            {
                Transform star = UIStars.GetChild(i);
                if (this.packageTableItem.star > i)
                {
                    star.gameObject.SetActive(true);
                }
                else
                {
                    star.gameObject.SetActive(false);
                }
            }
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            //Debug.Log("OnPointerEnter: " + eventData.ToString());

            UIMouseOverAni.gameObject.SetActive(true);
            UIMouseOverAni.GetComponent<Animator>().SetTrigger("In");
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            //Debug.Log("OnPointerExit: " + eventData.ToString());

            UIMouseOverAni.GetComponent<Animator>().SetTrigger("Out");
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            //Debug.Log("OnPointerClick: " + eventData.ToString());

            if(this.uiParent.currentMode==PackageMode.delete)
            {
                this.uiParent.AddChooseDeleteUid(this.packageLocalData.uid);
            }

            if(this.uiParent.chooseUid==this.packageLocalData.uid)
            {
                return;
            }
            this.uiParent.chooseUid = this.packageLocalData.uid;

            UISelectAni.gameObject.SetActive(true);
            UISelectAni.GetComponent<Animator>().SetTrigger("In");
        }

        public void RefreshDeleteState()
        {
            if(this.uiParent.deleteChooseUid.Contains(this.packageLocalData.uid))
            {
                this.UIDeleteSelect.gameObject.SetActive(true);
            }
            else
            {
                this.UIDeleteSelect.gameObject.SetActive(false);
            }
        }
    }
}
