using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class PackageReusableData
    {
        private static PackageReusableData _instance;

        public static PackageReusableData instance
        {
            get
            {
                if(_instance==null)
                {
                    _instance = new PackageReusableData();
                }

                return _instance;
            }
        }

        public bool isOpenPackage { get; set; } = false;
    }
}
