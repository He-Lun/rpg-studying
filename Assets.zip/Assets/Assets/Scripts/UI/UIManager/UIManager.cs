using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace jenshin
{
    public class UIManager
    {
        private static UIManager _instance;

        private Transform _uiRoot;

        private Dictionary<string, string> pathDict;

        private Dictionary<string, GameObject> prefabDict;

        public Dictionary<string, BasePanel> panelDict;

        private float originalTime = 1f;

        private float originalFixedDeltaTime = 1f;

        public Transform canvasTransform;

        public static UIManager instance
        {
            get
            {
                if(_instance==null)
                {
                    _instance = new UIManager();
                }
                return _instance;
            }
        }

        public Transform uiRoot
        {
            get
            {
                if(_uiRoot == null)
                {
                    if(GameObject.Find("Canvas"))
                    {
                        _uiRoot = GameObject.Find("Canvas").transform;
                    }
                    else
                    {
                        _uiRoot = new GameObject("Canvas").transform;
                    }
                };
                return _uiRoot;
            }
        }

        private UIManager()
        {
            InitDicts();
        }

        private void InitDicts()
        {
            pathDict = new Dictionary<string, string>()
            {
                { UIConst.packagePanel,"Prefab/UI/Panel/Inventory/PackagePanel"},
                { UIConst.pickUpPanel,"Prefab/UI/Panel/Interact/PickUpPanel"}
            };

            prefabDict = new Dictionary<string, GameObject>();

            panelDict = new Dictionary<string, BasePanel>();
        }

        public BasePanel GetPanel(string name)
        {
            BasePanel panel = null;
            
            if(panelDict.TryGetValue(name,out panel))
            {
                return panel;
            }
            return null;
        }

        public BasePanel OpenPanel(string name)
        {
            BasePanel panel = null;
            // ����Ƿ��Ѵ�
            if (panelDict.TryGetValue(name, out panel))
            {
                Debug.Log("�����Ѵ�: " + name);
                return null;
            }

            // ���·���Ƿ�����
            string path = "";
            if (!pathDict.TryGetValue(name, out path))
            {
                Debug.Log("�������ƴ��󣬻�δ����·��: " + name);
                return null;
            }

            // ʹ�û���Ԥ�Ƽ�
            GameObject panelPrefab = null;
            if (!prefabDict.TryGetValue(name, out panelPrefab))
            {
                string realPath = path;

                panelPrefab = Resources.Load<GameObject>(realPath) as GameObject;
                if (panelPrefab == null) // ���ӿ�ֵ�ж�
                {
                    Debug.LogError("����Ԥ�Ƽ�ʧ��: " + realPath);
                    return null;
                }
                prefabDict.Add(name, panelPrefab);
                Debug.Log(realPath);
            }

            // �򿪽���
            GameObject panelObject = GameObject.Instantiate(panelPrefab, uiRoot, false);
            panel = panelObject.GetComponent<BasePanel>();
            if (panel == null) // ���ӿ�ֵ�ж�
            {
                Debug.LogError("Ԥ�Ƽ�δ����BasePanel�ű�: " + name);
                return null;
            }
            panelDict.Add(name, panel);
            panel.OpenPanel(name);

            UIPriorityFilter.RefreshPriority();

            return panel;
        }

        public bool ClosePanel(string name)
        {
            BasePanel panel = null;
            if (!panelDict.TryGetValue(name, out panel))
            {
                Debug.Log("����δ��: " + name);
                return false;
            }

            if (panel == null) // ���ӿ�ֵ�ж�
            {
                Debug.LogError("���Ϊ�գ��޷��ر�: " + name);
                panelDict.Remove(name);
                return false;
            }

            panel.ClosePanel();
            panelDict.Remove(name);

            UIPriorityFilter.RefreshPriority();

            return true;
        }
    }



    public class UIConst
    {
        public const string packagePanel = "PackagePanel";
        public const string pickUpPanel = "PickUpPanel";
    }

}
