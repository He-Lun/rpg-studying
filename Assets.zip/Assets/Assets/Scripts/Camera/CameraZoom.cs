using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace jenshin
{
    public class CameraZoom : MonoBehaviour
    {
        [SerializeField][Range(0f, 10f)] private float defaultDistance = 6f;
        [SerializeField][Range(0f, 10f)] private float minDistance = 1f;
        [SerializeField][Range(0f, 10f)] private float maxDistance = 6f;

        [SerializeField][Range(0f, 10f)] private float zoomSensitivity = 1f;
        [SerializeField][Range(0f, 10f)] private float smoothing = 4f;

        private CinemachineFramingTransposer framingTransposer;
        private CinemachineInputProvider inputProvider;
        private float currntTargetDistance;

        private void Awake()
        {
            framingTransposer = GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>();
            inputProvider = GetComponent<CinemachineInputProvider>();

            currntTargetDistance = defaultDistance;
        }

        private void Update()
        {
            if(!GamePauseManager.instance.IsPaused)
            {
                Zoom();
            }
        }

        private void Zoom()
        {
            float zoomvalue = inputProvider.GetAxisValue(2) * zoomSensitivity;

            currntTargetDistance = Mathf.Clamp(currntTargetDistance + zoomvalue, minDistance, maxDistance);

            float currentDistance = framingTransposer.m_CameraDistance;

            if (currntTargetDistance == currentDistance)
            {
                return;
            }

            float lerpedZoomValue = Mathf.Lerp(currentDistance, currntTargetDistance, smoothing * Time.deltaTime);

            framingTransposer.m_CameraDistance = lerpedZoomValue;
        }
    }
}
