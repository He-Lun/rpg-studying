using UnityEngine;
using System.Collections.Generic;
using System;

namespace jenshin
{
    public class PackageLocalData
    {
        private static PackageLocalData _instance;

        public static PackageLocalData instance
        {
            get
            {
                if(_instance==null)
                {
                    _instance = new PackageLocalData();
                }

                return _instance;
            }
        }

        public List<PackageLocalItem> items;

        public void SavePackage()
        {
            string inventoryJson = JsonUtility.ToJson(this);

            PlayerPrefs.SetString("PackageLocalData", inventoryJson);

            PlayerPrefs.Save();
        }

        public List<PackageLocalItem> LoadPackage()
        {
            if(items!=null)
            {
                return items;
            }

            if(PlayerPrefs.HasKey("PackageLocalData"))
            {
                string inventoryJson = PlayerPrefs.GetString("PackageLocalData");

                PackageLocalData packageLocalData = JsonUtility.FromJson<PackageLocalData>(inventoryJson);

                items = packageLocalData.items;

                return items;
            }
            else
            {
                items = new List<PackageLocalItem>();

                return items;
            }
        }

        public void ClearAll()
        {
            PlayerPrefs.DeleteKey("PackageLocalData");
            PlayerPrefs.Save();
            Debug.Log("����ձ�����������");
        }
    }

    [Serializable]
    public class PackageLocalItem
    {
        public string uid;

        public int id;

        public int number;

        public int level;

        public bool isNew;

        public override string ToString()
        {
            return string.Format("[id]:{0},[num]:{1}", id, number);
        }
    }
}
