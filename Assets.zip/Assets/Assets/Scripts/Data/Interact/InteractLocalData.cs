using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace jenshin
{
    public class InteractLocalData
    {
        private static InteractLocalData _instance;

        public static InteractLocalData instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new InteractLocalData();
                }

                return _instance;
            }
            set
            {
                _instance = value;
            }
        }

        public event Action OnInteractablesChanged;

        public List<BaseInteractData> interactables;

        public void AddInteractables(BaseInteractData interactData)
        {
            interactables.Add(interactData);

            OnInteractablesChanged?.Invoke();
        }

        public void RemoveInteractables(BaseInteractData interactData)
        {
            BaseInteractData dataToRemove = null;

            foreach(BaseInteractData data in interactables)
            {
                if (data.Uid == interactData.Uid)
                {
                    dataToRemove = data;
                    break;
                }
            }

            if(dataToRemove!=null)
            {
                interactables.Remove(dataToRemove);

                OnInteractablesChanged?.Invoke();
            }
        }
    }

    // ͨ�ý�������ģ�ͣ���������/��/NPC��
    public class BaseInteractData
    {
        public string Uid { get; set; } // Ψһ��ʶ
        public int id { get; set; }
        public string Name { get; set; } // ��ʾ���ƣ������/ľ��/��ɪ�գ�
        public string InteractTip { get; set; } // ������ʾ��ʰȡ/����/�Ի���
        public int Priority { get; set; } // ���ȼ�����=100������=10��NPC=5��
        public System.Action OnInteract { get; set; } // ����ִ���߼�
        public object RawData { get; set; } // ԭʼ���ݣ�PackageLocalItem/Door/NPCDialogue��
    }
}
