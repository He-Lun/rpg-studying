using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [Serializable]
    public class DefaultColliderData
    {
        [field: SerializeField] public float height { get; private set; } = 1.82f;
        [field: SerializeField] public float centerY { get; private set; } = 0.91f;
        [field: SerializeField] public float Radius { get; private set; } = 0.16f;
    }
}
