using UnityEngine;
using jenshin;
using System.Collections.Generic;
using UnityEditor.Rendering;

namespace jenshin
{
    public class WeaponPickup : MonoBehaviour
    {
        // ʰȡ���Ӧ������ID�������PackageTable_SO�е�id��Ӧ��
        [Header("��������")]
        public int weaponId;
        // ʰȡ���õ�����������һ��Ϊ1��
        public int pickupCount = 1;
        // ��ʼ�ȼ�
        public int initialLevel = 1;
        //uid
        public string uid;

        BaseInteractData interactData = null;

        // ��ײ���
        public void OnTriggerEnter(Collider other)
        {
            // �����ײ�����Ƿ������
            if (other.CompareTag("Player"))
            {
                LetUIOn();
            }
        }

        public void OnTriggerExit(Collider other)
        {
            if(other.CompareTag("Player"))
            {
                LetUIOff();
            }
        }

        // ���ģ�ʰȡ�����߼�
        public void Interact()
        {
            // 2. ��������������Ʒ����
            PackageLocalItem newWeaponItem = new PackageLocalItem()
            {
                uid = this.uid,
                id = weaponId,
                number = pickupCount,
                level = initialLevel,
                isNew = true
            };

            // 3. ���ӵ�������������
            List<PackageLocalItem> packageItems = PackageLocalData.instance.LoadPackage();
            packageItems.Add(newWeaponItem);
            PackageLocalData.instance.items = packageItems;

            // 4. ���汳�����ݵ�PlayerPrefs
            PackageLocalData.instance.SavePackage();

            // 5. ˢ�±���UI����������Ѵ򿪣�
            RefreshPackageUI();

            // 6. ����ʰȡ������ظ�ʰȡ��
            Destroy(gameObject);

            Debug.Log($"ʰȡ������{GameManager.instance.GetPackageItemById(weaponId)?.name}��UID��{this.uid}");
        }

        // ˢ�±���UI
        private void RefreshPackageUI()
        {
            // ��鱳���Ƿ��Ѵ�
            BasePanel packagePanel = UIManager.instance.GetPanel(UIConst.packagePanel);
            if (packagePanel != null && packagePanel is PackagePanel)
            {
                (packagePanel as PackagePanel).RefreshUI();
            }
        }

        // ֪ͨUI��ʾʰȡ��ʾ
        public void LetUIOn()
        {
            UploadData();

            UIManager.instance.OpenPanel(UIConst.pickUpPanel);
        }

        public void LetUIOff()
        {
            RemoveData();

            if (InteractLocalData.instance.interactables.Count > 0)
            {
                return;
            }

            UIManager.instance.ClosePanel(UIConst.pickUpPanel);
        }

        private void UploadData()
        {
            uid = System.Guid.NewGuid().ToString();

            if (InteractLocalData.instance.interactables == null)
            {
                InteractLocalData.instance.interactables = new List<BaseInteractData>();
            }

            interactData = new BaseInteractData
            {
                Uid = uid,
                id = weaponId,
                Name = "��ӥ��",
                InteractTip = "ʰȡ",
                Priority = 10,
                OnInteract = () => Interact(),
                RawData = GameManager.instance.GetPackageItemById(weaponId)
            };

            if (interactData != null)
            {
                InteractLocalData.instance.AddInteractables(interactData);
            }
        }

        private void RemoveData()
        {
            if(interactData!=null)
            {
                InteractLocalData.instance.RemoveInteractables(interactData);
            }
        }
    }
}
