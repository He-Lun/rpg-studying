using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [Serializable]
    public class PlayerCapsuleColliderUtility : CapsuleColliderUnity
    {
        [field: SerializeField] public PlayerTriggerColliderData triggerColliderData { get; private set; }
    }
}
