using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [Serializable]
    public class CapsuleColliderUnity
    {
         public CapsuleColliderData capsuleColliderData { get; private set; }

        [field: SerializeField] public DefaultColliderData defaultColliderData { get; private set; }

        [field: SerializeField] public SlopeData slopeData { get; private set; }

        public void Initialize(GameObject gameObject)
        {
            if(capsuleColliderData!=null)
            {
                return;
            }

            capsuleColliderData = new CapsuleColliderData();

            capsuleColliderData.Initialize(gameObject);
        }

        public void CalculateCapsuleColliderDimensions()
        {
            SetCapsuleColliderRadius(defaultColliderData.Radius);

            SetCapsuleColliderHeight(defaultColliderData.height * (1f - slopeData.slopeHeightPercentage));

            RecalculateCapsuleColliderCenter();

            float halfColliderHeight = capsuleColliderData.collider.height / 2f;
            if (halfColliderHeight < capsuleColliderData.collider.radius)
            {
                SetCapsuleColliderRadius(halfColliderHeight);
            }

            capsuleColliderData.UpdateColliderData();
        }

        public void RecalculateCapsuleColliderCenter()
        {
            float colliderHeightDifference = defaultColliderData.height - capsuleColliderData.collider.height;

            Vector3 newColliderCenter = new Vector3(0f, defaultColliderData.centerY + (colliderHeightDifference / 2f), 0f);

            capsuleColliderData.collider.center = newColliderCenter;
        }

        public void SetCapsuleColliderRadius(float radius)
        {
            capsuleColliderData.collider.radius = radius;
        }

        public void SetCapsuleColliderHeight(float height)
        {
            capsuleColliderData.collider.height = height;
        }
    }
}
