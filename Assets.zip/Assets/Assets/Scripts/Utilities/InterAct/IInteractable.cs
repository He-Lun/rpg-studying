using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace jenshin
{
    public interface IInteractable
    {
        public void Interact();

        public void OnTriggerEnter();

        public void OnTriggerExit();
    }
}
