using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [CreateAssetMenu (menuName ="PackageData",fileName ="PackageTable")]
    public class PackageTable_SO : ScriptableObject
    {
        public List<PackageTableItem> dataList = new List<PackageTableItem>();
    }

    [Serializable]
    public class PackageTableItem
    {
        public int id;

        public int type;

        public int star;

        public string name;

        public string description;

        public string skillDescription;

        public string imagePath;

        public int number;
    }
}
