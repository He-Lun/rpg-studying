using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace jenshin
{
    public class CharacterAttrManager : Singleton<CharacterAttrManager>
    {
        // ��������SO�������ظ����أ�
        private Dictionary<string, PlayeConfig_SO> configDict = new Dictionary<string, PlayeConfig_SO>();
        // ���浱ǰ��ɫ״̬������ʱ��
        private Dictionary<string, CharacterStateData> curStateDict = new Dictionary<string, CharacterStateData>();

        // ���Ա仯�¼�����UI/ս�����ģ�
        public event Action<string, CharacterAttributeType, float> OnAttributeChanged;

        #region Initial/Load
        // ���ؽ�ɫ���ã���Resources�ļ��У�
        public PlayeConfig_SO LoadCharacterConfig(string characterId)
        {
            if (configDict.ContainsKey(characterId))
                return configDict[characterId];

            // ��������SO����Resources/CharacterConfigs/Ŀ¼��
            PlayeConfig_SO config = Resources.Load<PlayeConfig_SO>(AttrConst.attrPath_HeLun + $"/{characterId}");
            if (config == null)
            {
                Debug.LogError($"δ�ҵ���ɫ���ã�{characterId}");
                return null;
            }

            configDict.Add(characterId, config);
            return config;
        }

        // ���ؽ�ɫ״̬���ӱ��ش浵��
        public CharacterStateData LoadCharacterState(string characterId)
        {
            if (curStateDict.ContainsKey(characterId))
                return curStateDict[characterId];

            // ��PlayerPrefs��ȡJSON��������ѡ���򵥣�
            string json = PlayerPrefs.GetString($"CharacterState_{characterId}", "");
            CharacterStateData state = string.IsNullOrEmpty(json)
                ? new CharacterStateData(LoadCharacterConfig(characterId))
                : JsonUtility.FromJson<CharacterStateData>(json);

            curStateDict.Add(characterId, state);
            return state;
        }
        #endregion

        #region AttrCalculating
        // ��ȡ��ɫ��ǰ����ֵ���Զ����㶯̬+��̬��
        public float GetAttributeValue(string characterId, CharacterAttributeType attrType)
        {
            PlayeConfig_SO config = LoadCharacterConfig(characterId);
            CharacterStateData state = LoadCharacterState(characterId);
            if (config == null || state == null) return 0;

            switch (attrType)
            {
                case CharacterAttributeType.MaxHP:
                    return config.baseMaxHP + (state.currentLevel - 1) * config.hpGrowth;
                case CharacterAttributeType.CurrentHP:
                    return state.currentHP;
                case CharacterAttributeType.Attack:
                    return config.baseAttack + (state.currentLevel - 1) * config.attackGrowth;
                case CharacterAttributeType.Defense:
                    return config.baseDefense + (state.currentLevel - 1) * config.defenseGrowth;
                default:
                    return 0;
            }
        }

        // �޸Ķ�̬���ԣ����Ѫ����Ѫ��
        public void ModifyAttribute(string characterId, CharacterAttributeType attrType, float value)
        {
            CharacterStateData state = LoadCharacterState(characterId);
            if (state == null) return;

            float oldValue = 0;
            float maxHP = GetAttributeValue(characterId, CharacterAttributeType.MaxHP);

            switch (attrType)
            {
                case CharacterAttributeType.CurrentHP:
                    oldValue = state.currentHP;
                    state.currentHP = Mathf.Clamp(state.currentHP + value, 0, maxHP); // ����0~�������ֵ
                    break;
                    // ����չ��������̬���ԣ�����ʱ�������ӳɣ�
            }

            // �������Ա仯�¼���֪ͨUIˢ�£�
            OnAttributeChanged?.Invoke(characterId, attrType, state.currentHP);
            // �Զ�����״̬
            SaveCharacterState(characterId);
        }
        #endregion

        #region SaveToLocal
        // �����ɫ״̬������
        public void SaveCharacterState(string characterId)
        {
            if (!curStateDict.ContainsKey(characterId)) return;

            string json = JsonUtility.ToJson(curStateDict[characterId]);
            PlayerPrefs.SetString($"CharacterState_{characterId}", json);
            PlayerPrefs.Save();
        }

        // ��ս�ɫ״̬�����ã�
        public void ResetCharacterState(string characterId)
        {
            PlayeConfig_SO config = LoadCharacterConfig(characterId);
            curStateDict[characterId] = new CharacterStateData(config);
            SaveCharacterState(characterId);
        }
        #endregion
    }

    public class AttrConst
    {
        public const string attrPath_HeLun = "ScriptableObjects/Characters/Player";
    }
}
