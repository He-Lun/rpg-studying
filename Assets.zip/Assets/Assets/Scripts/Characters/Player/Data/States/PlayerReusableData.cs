using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class PlayerReusableData
    {
        public Vector2 movementInput { get; set; }
        public float movementOnSlopeSpeedModifier { get; set; } = 1f;
        public float movementSpeedModifier { get; set; } = 1f;
        public bool shouldWalk { get; set; }
        public bool shouldSprint { get; set; }
        public float movementDecelerationForce { get; set; }

        private Vector3 currentTargetRotation;
        private Vector3 timeToReachTargetRotation;
        private Vector3 dampedTargetRotationCurrentVelocity;
        private Vector3 dampedTargetRotationPassedTime;
        public ref Vector3 CurrentTargetRotation
        {
            get
            {
                return ref currentTargetRotation;
            }
        }
        public ref Vector3 TimeToReachTargetRotation
        {
            get
            {
                return ref timeToReachTargetRotation;
            }
        }
        public ref Vector3 DampedTargetRotationCurrentVelocity
        {
            get
            {
                return ref dampedTargetRotationCurrentVelocity;
            }
        }
        public ref Vector3 DampedTargetRotationPassedTime
        {
            get
            {
                return ref dampedTargetRotationPassedTime;
            }
        }

        public Vector3 currentJumpForce { get; set; }

        public PlayerRotationData rotationData { get; set; }
    }
}
