using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [CreateAssetMenu(fileName ="Player",menuName ="Custom/Characters/Players")]
    public class Player_So : ScriptableObject
    {
        [field:SerializeField] public PlayerGroundedData groundedData { get; private set; }
        [field: SerializeField] public PlayerAirborneData airborneData { get; private set; }
    }
}
