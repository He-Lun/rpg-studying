using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class CharacterStateData
    {
        public string characterId; // ��������SO��ID
        public int currentLevel; // ��ǰ�ȼ�
        public float currentHP; // ��ǰ����ֵ

        public CharacterStateData() { }

        public CharacterStateData(PlayeConfig_SO config)
        {
            characterId = config.characterId;
            currentLevel = config.initialLevel;
            currentHP = config.baseMaxHP + (config.initialLevel - 1) * config.hpGrowth;
        }
    }
}
