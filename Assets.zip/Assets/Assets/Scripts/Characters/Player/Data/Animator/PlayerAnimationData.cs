using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    [Serializable]
    public class PlayerAnimationData
    {
        [Header("State Group Parameter Names")]
        [SerializeField] private string groundedParameterName = "Grounded";
        [SerializeField] private string movingParameterName = "Moving";
        [SerializeField] private string stoppingParameterName = "Stopping";
        [SerializeField] private string landingParameterName = "Landing";
        [SerializeField] private string airborneParameterName = "Airborne";

        [Header("Grounded Parameter Names")]
        [SerializeField] private string idleParameterName = "isIdling";
        [SerializeField] private string walkParameterName = "isWalking";
        [SerializeField] private string dashParameterName = "isDashing";
        [SerializeField] private string sprintParameterName = "isSprinting";
        [SerializeField] private string mediumStopParameterName = "isMediumStopping";
        [SerializeField] private string runParameterName = "isRunning";
        [SerializeField] private string hardStopParameterName = "isHardStopping";
        [SerializeField] private string rollParameterName = "isRolling";
        [SerializeField] private string hardLandParameterName = "isHardLanding";
        [SerializeField] private string fallParameterName = "isFalling";

        public int groundedParameterHash { get; private set; }
        public int movingParameterHash { get; private set; }
        public int stoppingParameterHash { get; private set; }
        public int landingParameterHash { get; private set; }
        public int airborneParameterHash { get; private set; }
        public int idleParameterHash { get; private set; }
        public int walkParameterHash { get; private set; }
        public int dashParameterHash { get; private set; }
        public int sprintParameterHash { get; private set; }
        public int mediumStopParameterHash { get; private set; }
        public int runParameterHash { get; private set; }
        public int hardStopParameterHash { get; private set; }
        public int rollParameterHash { get; private set; }
        public int hardLandParameterHash { get; private set; }
        public int fallParameterHash { get; private set; }

        public void Initialize()
        {
            groundedParameterHash = Animator.StringToHash(groundedParameterName);
            movingParameterHash = Animator.StringToHash(movingParameterName);
            stoppingParameterHash = Animator.StringToHash(stoppingParameterName);
            landingParameterHash = Animator.StringToHash(landingParameterName);
            airborneParameterHash = Animator.StringToHash(airborneParameterName);

            idleParameterHash = Animator.StringToHash(idleParameterName);
            walkParameterHash = Animator.StringToHash(walkParameterName);
            dashParameterHash = Animator.StringToHash(dashParameterName);
            sprintParameterHash = Animator.StringToHash(sprintParameterName);
            mediumStopParameterHash = Animator.StringToHash(mediumStopParameterName);
            runParameterHash = Animator.StringToHash(runParameterName);
            hardStopParameterHash = Animator.StringToHash(hardStopParameterName);
            rollParameterHash = Animator.StringToHash(rollParameterName);
            hardLandParameterHash = Animator.StringToHash(hardLandParameterName);
            fallParameterHash = Animator.StringToHash(fallParameterName);
        }
    }
}
