using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    [RequireComponent(typeof(PlayerInput))]
    public class Player : MonoBehaviour,IPausable
    {
        [field:Header("References")]
        [field:SerializeField] public Player_So Data { get; private set; }
        [field: SerializeField] public PlayeConfig_SO Config { get; private set; }

        [field:Header("Collisions")]
        [field: SerializeField] public PlayerCapsuleColliderUtility colliderUnity { get; private set; }
        [field: SerializeField] public PlayerLayerData layerData { get; private set; }

        [field: Header("Animations")]
        [field: SerializeField] public PlayerAnimationData animationData { get; private set; }

        public Transform mainCameraTransform { get; private set; }

        private PlayerMovementStateMachine movementStateMachine;

        public static PlayerInput Input { get; private set; }

        public Rigidbody rb { get; private set; }

        public Animator animator { get; private set; }

        public InputAction action;

        public CinemachineInputProvider inputProvider { get; private set; }

        // ������ͣǰ��״̬����ֹ�ָ�ʱ���ң�
        private Vector3 _pausePosition;    // ��ͣʱ��λ�ã�����Y�ᣩ
        private bool _isPaused = false;    // ������ͣ���

        public void Awake()
        {
            Input = GetComponent<PlayerInput>();

            animator = GetComponentInChildren<Animator>();
            animator.applyRootMotion = false;

            colliderUnity.Initialize(gameObject);
            colliderUnity.CalculateCapsuleColliderDimensions();

            animationData.Initialize();

            movementStateMachine = new PlayerMovementStateMachine(this);

            rb = GetComponent<Rigidbody>();

            mainCameraTransform = Camera.main.transform;

            inputProvider = FindObjectOfType<CinemachineInputProvider>();

            CharacterAttrManager.Instance.LoadCharacterState(Config.characterId);
            CharacterAttrManager.Instance.OnAttributeChanged += OnAttributeChanged;

            // ע�ᵽ��ͣ������
            GamePauseManager.instance.RegisterPausable(this);
        }

        private void OnValidate()
        {
            colliderUnity.Initialize(gameObject);
            colliderUnity.CalculateCapsuleColliderDimensions();
        }

        public void OnTriggerEnter(Collider collider)
        {
            movementStateMachine.OnTriggerEnter(collider);
        }

        private void OnTriggerExit(Collider other)
        {
            movementStateMachine.OnTriggerExit(other);
        }

        public void Start()
        {
            //�������
            Cursor.lockState = CursorLockMode.Locked;

            movementStateMachine.ChangeState(movementStateMachine.idlingState);
        }

        public void Update()
        {
            if(_isPaused)
            {
                return;
            }

            movementStateMachine.HandleInput();

            movementStateMachine.Update();
        }

        public void FixedUpdate()
        {
            if(_isPaused)
            {
                return;
            }

            movementStateMachine.PhysicsUpdate();
        }

        public void OnMovementStateAnimationEnterEvent()
        {
            movementStateMachine.OnAnimationEnterEvent();
        }

        public void OnMovementStateAnimationExitEvent()
        {
            movementStateMachine.OnAnimationExitEvent();
        }

        public void OnMovementStateAnimationTransitionEvent()
        {
            movementStateMachine.OnAnimationTransitionEvent();
        }

        public void OnPause()
        {
            if (_isPaused) return;

            // 1. ������ͣλ�ã�����Y���ã�
            _pausePosition = transform.position;

            // 2. ������壨�ž�����/��ײ���µĸ��գ�
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.isKinematic = true;

            // 3. ��ͣ�������޹���
            animator.speed = 0;

            // 4. �������루������ϣ�
            Input.InputActions.Player.Disable();

            //5.�����������
            if (inputProvider != null)
            {
                inputProvider.enabled = false;
            }

            // 6. �����ͣ״̬
            _isPaused = true;
        }

        public void OnResume()
        {
            if (!_isPaused) return;

            // 1. �ָ����壨����������
            rb.isKinematic = false;
            rb.WakeUp(); // ���Ѹ��壬��ֹ��������Ӧ

            // 2. �ָ�����
            animator.speed = 1;

            // 3. �ָ�����
            Input.InputActions.Player.Enable();

            //4.�������

            if (inputProvider != null)
            {
                inputProvider.enabled = true;
            }

            // 5. ������ͣ���
            _isPaused = false;
        }

        #region AttrManagement
        // ��Ѫ
        public void TakeDamage(float damage)
        {
            CharacterAttrManager.Instance.ModifyAttribute(
                Config.characterId,
                CharacterAttributeType.CurrentHP,
                -damage); // ����=��Ѫ
        }

        // ��Ѫ
        public void Heal(float healValue)
        {
            CharacterAttrManager.Instance.ModifyAttribute(
                Config.characterId,
                CharacterAttributeType.CurrentHP,
                healValue);
        }

        // ��ȡ��ǰ����ֵ
        public float GetCurrentHP()
        {
            return CharacterAttrManager.Instance.GetAttributeValue(
                Config.characterId,
                CharacterAttributeType.CurrentHP);
        }

        // ��ȡ�������ֵ
        public float GetMaxHP()
        {
            return CharacterAttrManager.Instance.GetAttributeValue(
                Config.characterId,
                CharacterAttributeType.MaxHP);
        }

        // ���Ա仯�ص���ˢ��UI��
        private void OnAttributeChanged(string characterId, CharacterAttributeType attrType, float value)
        {
            if (characterId != Config.characterId) return;

            if (attrType == CharacterAttributeType.CurrentHP)
            {
                // ʾ����ˢ��Ѫ��UI
                // UIManager.instance.GetPanel<HUDPanel>().RefreshHPBar(value, GetMaxHP());
                Debug.Log($"��ɫ{Config.characterName}��ǰ����ֵ��{value}/{GetMaxHP()}");
            }
        }
        #endregion

        private void OnDestroy()
        {
            // ע����ͣ���󣨷�ֹ�ڴ�й©��
            GamePauseManager.instance.UnregisterPausable(this);
        }
    }
}
