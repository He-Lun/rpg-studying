using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class WalkingState : PlayerMovingState
    {
        public WalkingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.walkParameterHash);

            stateMachine.reusableData.movementSpeedModifier = movementData.walkData.speedModifier;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.weakForce;
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.walkParameterHash);
        }
        #endregion

        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.lightStoppingState);
        }

        protected override void OnWalkToggleStarted(InputAction.CallbackContext context)
        {
            base.OnWalkToggleStarted(context);

            stateMachine.ChangeState(stateMachine.runningState);
        }
        #endregion
    }
}
