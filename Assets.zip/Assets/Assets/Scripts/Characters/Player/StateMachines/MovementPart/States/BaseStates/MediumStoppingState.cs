using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class MediumStoppingState : StoppingState
    {
        public MediumStoppingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.mediumStopParameterHash);

            stateMachine.reusableData.movementDecelerationForce = movementData.stopData.mediumDecelerationForce;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.mediumForce;
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.mediumStopParameterHash);
        }
        #endregion
    }
}
