using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace jenshin
{
    public class IdlingState : PlayerMovingState
    {
        public IdlingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {

        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            stateMachine.reusableData.movementSpeedModifier = 0f;

            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.stationaryForce;

            ResetVelocity();

            StartAnimation(stateMachine.player.animationData.idleParameterHash);
            StopAnimation(stateMachine.player.animationData.movingParameterHash);
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.idleParameterHash);
        }

        public override void Update()
        {
            base.Update();

            if(stateMachine.reusableData.movementInput==Vector2.zero)
            {
                return;
            }

            OnMove();
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            //if (!IsMovingHorizontally())
               //return;

            ResetVelocity();
        }
        #endregion
    }
}
