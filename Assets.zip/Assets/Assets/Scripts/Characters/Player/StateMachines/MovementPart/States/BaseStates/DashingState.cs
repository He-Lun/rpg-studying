using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Playables;

namespace jenshin
{
    public class DashingState : PlayerGroundedState
    {
        private bool shouleKeepRotating;
        private PlayerDashData dashData;
        private float startTime;
        private int consecutiveDashesUsed;
        public DashingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            dashData = movementData.dashData;
        }

        #region IState
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.dashParameterHash);

            stateMachine.reusableData.movementSpeedModifier = dashData.speedModifier;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.strongForce;

            stateMachine.reusableData.rotationData = dashData.rotationData;

            Dash();

            shouleKeepRotating = stateMachine.reusableData.movementInput != Vector2.zero;

            UpdateConsecutiveDashes();

            startTime = Time.time;
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.dashParameterHash);

            SetBaseRotationData();
        }

        public override void OnAnimationTransitionEvent()
        {
            if (stateMachine.reusableData.movementInput == Vector2.zero)
            {
                stateMachine.ChangeState(stateMachine.hardStoppingState);

                return;
            }

            stateMachine.ChangeState(stateMachine.sprintingState);
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            if (!shouleKeepRotating) return;

            RotateTowardsTargetRotation();
        }
        #endregion

        #region Main Methods
        private void Dash()
        {
            Vector3 dashDirection = stateMachine.player.transform.forward;

            dashDirection.y = 0f;

            UpdateTargetRotation(dashDirection, false);

            if (stateMachine.reusableData.movementInput!=Vector2.zero)
            {
                UpdateTargetRotation(GetMovementInputDirection());

                dashDirection = GetTargetDirectionRotation(stateMachine.reusableData.CurrentTargetRotation.y);
            }

            stateMachine.player.rb.velocity = dashDirection * GetMovementSpeed(false);
        }

        private void UpdateConsecutiveDashes()
        {
            if (!IsConsecutive())
            {
                consecutiveDashesUsed = 0;
            }

            consecutiveDashesUsed++;

            if(consecutiveDashesUsed==dashData.consecutiveDashLimitAmount)
            {
                consecutiveDashesUsed = 0;

                Player.Input.DisableActionFor(Player.Input.playerActions.Dash, dashData.timeLimitReachedCooldown);
            }
        }

        private bool IsConsecutive()
        {
            return Time.time < startTime + dashData.timeToBoConsideredConsecutive;
        }
        #endregion

        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
        }

        protected override void OnDashStarted(InputAction.CallbackContext context)
        {
        }

        private void OnMovementPerformed(InputAction.CallbackContext context)
        {
            shouleKeepRotating = true;
        }
        #endregion

        #region Reusable Methods
        protected override void AddInputActionsCallBack()
        {
            base.AddInputActionsCallBack();

            Player.Input.playerActions.Movement.performed += OnMovementPerformed;
        }

        protected override void RemoveInputActionsCallBack()
        {
            base.RemoveInputActionsCallBack();

            Player.Input.playerActions.Movement.performed -= OnMovementPerformed;
        }
        #endregion
    }
}
