using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class StoppingState : PlayerGroundedState
    {
        private float lockingMovementInputStartedTime;

        public StoppingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        public override void Enter()
        {
            stateMachine.reusableData.movementSpeedModifier = 0f;

            base.Enter();

            StartAnimation(stateMachine.player.animationData.stoppingParameterHash);
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.stoppingParameterHash);
        }

        public override void Update()
        {
            base.Update();
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();


            if (!IsMovingHorizontally())
            {
                return;
            }

            DecelerateHorizontally();

            RotateTowardsTargetRotation();
        }

        public override void OnAnimationTransitionEvent()
        {
            stateMachine.ChangeState(stateMachine.idlingState);
        }

        #region Reusable Methods
        protected override void AddInputActionsCallBack()
        {
            base.AddInputActionsCallBack();

            Player.Input.playerActions.Movement.started += OnMovementStarted;
        }

        protected override void RemoveInputActionsCallBack()
        {
            base.RemoveInputActionsCallBack();

            Player.Input.playerActions.Movement.started -= OnMovementStarted;
        }
        #endregion

        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
        }

        private void OnMovementStarted(InputAction.CallbackContext context)
        {
            OnMove();
        }
        #endregion
    }
}
