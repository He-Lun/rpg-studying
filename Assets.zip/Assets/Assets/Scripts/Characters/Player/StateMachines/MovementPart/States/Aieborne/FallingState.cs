using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

namespace jenshin
{
    public class FallingState : AirborneState
    {
        private PlayerFallData fallData;

        private Vector3 PlayerPositionOnEnter;

        public FallingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            fallData = airborneData.fallData;
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.fallParameterHash);

            PlayerPositionOnEnter = stateMachine.player.transform.position;

            stateMachine.reusableData.movementSpeedModifier = 0f;

            ResetVerticalVelocity();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.fallParameterHash);
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            LimitVerticalVelocity();
        }
        #endregion

        #region Reusable Methods
        protected override void ResetSprintState()
        {
        }

        //����������������������������׹���˺����ӡ�������������������������������
        protected override void OnContactWithGround(Collider collider)
        {
            float fallDistance = MathF.Abs(PlayerPositionOnEnter.y - stateMachine.player.transform.position.y);

            if (fallDistance < fallData.minimumDistanceToBeConsideredHardFall)
            {
                stateMachine.ChangeState(stateMachine.lightLandingState);

                return;
            }

            if (stateMachine.reusableData.shouldWalk&&!stateMachine.reusableData.shouldSprint
                ||stateMachine.reusableData.movementInput == Vector2.zero)
            {
                stateMachine.ChangeState(stateMachine.hardLandingState);

                return;
            }

            stateMachine.ChangeState(stateMachine.rollingState);
        }
        #endregion

        #region Main Methods
        private void LimitVerticalVelocity()
        {
            Vector3 playerVertialVelocity = GetVerticalVelocity();

            if (playerVertialVelocity.y >= -fallData.fallSpeedLimit)
            {
                return;
            }

            Vector3 limitedVerticalVelocity = new Vector3(0f, -fallData.fallSpeedLimit - playerVertialVelocity.y, 0f);

            stateMachine.player.rb.AddForce(limitedVerticalVelocity, ForceMode.VelocityChange);
        }
        #endregion
    }
}
