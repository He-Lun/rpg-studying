using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class RunningState : PlayerMovingState
    {
        private PlayerSprintData sprintData;
        private float startTime;
        public RunningState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            sprintData = movementData.sprintData;
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.runParameterHash);

            stateMachine.reusableData.movementSpeedModifier = movementData.runData.speedModifier;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.mediumForce;

            startTime = Time.time;
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.runParameterHash);
        }

        public override void Update()
        {
            base.Update();

            if (!stateMachine.reusableData.shouldWalk) return;

            if (Time.time < startTime + sprintData.runToWalkTime) return;

            StopRunning();
        }

        private void StopRunning()
        {
            if (stateMachine.reusableData.movementInput == Vector2.zero)
            {
                stateMachine.ChangeState(stateMachine.idlingState);
                return;
            }

            stateMachine.ChangeState(stateMachine.walkingState);
        }
        #endregion

        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.mediumStoppingState);
        }

        protected override void OnWalkToggleStarted(InputAction.CallbackContext context)
        {
            base.OnWalkToggleStarted(context);

            stateMachine.ChangeState(stateMachine.walkingState);
        }
        #endregion
    }
}
