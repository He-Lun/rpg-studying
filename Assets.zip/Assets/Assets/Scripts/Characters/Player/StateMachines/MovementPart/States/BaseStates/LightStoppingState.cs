using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class LightStoppingState : StoppingState
    {
        public LightStoppingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }
        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            stateMachine.reusableData.movementDecelerationForce = movementData.stopData.lightDecelerationForce;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.weakForce;
        }
        #endregion
    }
}
