using KinematicCharacterController;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class JumpState : AirborneState
    {
        private bool canStartFalling;
        private bool shouldKeepRotating;
        private PlayerJumpData jumpData;
        public JumpState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            jumpData = airborneData.jumpData;
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            stateMachine.reusableData.rotationData = jumpData.rotationData;

            stateMachine.reusableData.movementSpeedModifier = 0f;

            stateMachine.reusableData.movementDecelerationForce = jumpData.decelerationForce;

            shouldKeepRotating = stateMachine.reusableData.movementInput != Vector2.zero;

            Jump();
        }

        public override void Exit()
        {
            base.Exit();

            SetBaseRotationData();

            canStartFalling = false;
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            if(shouldKeepRotating)
            {
                RotateTowardsTargetRotation();
            }

            if(IsMovingUp())
            {
                DecelerateVertically();
            }
        }

        public override void Update()
        {
            base.Update();

            if (!canStartFalling && IsMovingUp())
            {
                canStartFalling = true;
            }

            if (!canStartFalling || GetVerticalVelocity().y > 0f)
            {
                return;
            }

            stateMachine.ChangeState(stateMachine.fallingState);
        }
        #endregion

        #region Reusable Methods
        protected override void ResetSprintState()
        {
            base.ResetSprintState();
        }
        #endregion

        #region Main Methods
        private void Jump()
        {
            Vector3 jumpForce = stateMachine.reusableData.currentJumpForce;

            Vector3 jumpDirection = stateMachine.player.transform.forward;

            if(shouldKeepRotating)
            {
                jumpDirection = GetTargetDirectionRotation(stateMachine.reusableData.CurrentTargetRotation.y);
            }

            jumpForce.x *= jumpDirection.x;
            jumpForce.z *= jumpDirection.z;

            Vector3 capsuleColliderCenterInWorldSpace = stateMachine.player.colliderUnity.capsuleColliderData.collider.bounds.center;

            Ray downwardsRayFromCapsuleCenter = new Ray(capsuleColliderCenterInWorldSpace, Vector3.down);

            //������ô������
            if (Physics.Raycast(downwardsRayFromCapsuleCenter, out RaycastHit hit, jumpData.jumpToGroundRayDistance, stateMachine.player.layerData.groundLayer,
                QueryTriggerInteraction.Ignore))
            {
                float groundAngle = Vector3.Angle(hit.normal, -downwardsRayFromCapsuleCenter.direction);

                if (IsMovingUp())
                {
                    float forceModifier = jumpData.jumpForceModifierOnSlopeUpwards.Evaluate(groundAngle);

                    jumpForce.x *= forceModifier;
                    jumpForce.z *= forceModifier;
                    if (forceModifier < 0.9f)
                    {
                        jumpForce.y *= 1.2f;
                    }
                }

                if (IsMovingDown())
                {
                    float forceModifier = jumpData.jumpForceModifierOnSlopeDownwards.Evaluate(groundAngle);

                    jumpForce.y *= forceModifier;
                }
            }

            //�ڴ��޸ģ����п���ת��
            ResetVelocity();

            stateMachine.player.rb.AddForce(jumpForce, ForceMode.VelocityChange);
        }
        #endregion
    }
}
