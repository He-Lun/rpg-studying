using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class AirborneState : MovementState
    {
        public AirborneState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.airborneParameterHash);

            ResetSprintState();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.airborneParameterHash);
        }
        #endregion

        #region Reusable Methods
        protected override void OnContactWithGround(Collider collider)
        {
            stateMachine.ChangeState(stateMachine.lightLandingState);
        }

        protected virtual void ResetSprintState()
        {
            stateMachine.reusableData.shouldSprint = false;
        }
        #endregion


    }
}
