using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering.Universal;

namespace jenshin
{
    public class MovementState : IState
    {
        protected PlayerGroundedData movementData;
        protected PlayerAirborneData airborneData;
        
        protected PlayerMovementStateMachine stateMachine;

        //���캯��
        public MovementState(PlayerMovementStateMachine playerMovementStateMachine)
        {
            stateMachine = playerMovementStateMachine;

            movementData = stateMachine.player.Data.groundedData;
            airborneData = stateMachine.player.Data.airborneData;
            
            InitializeData();
        }

        #region IState Methods
        public virtual void Enter()
        {
            Debug.Log("State: " + GetType().Name);

            AddInputActionsCallBack();
        }

        public virtual void Exit()
        {
            RemoveInputActionsCallBack();
        }

        public virtual void HandleInput()
        {
            ReadMovementInput();
        }
        public virtual void PhysicsUpdate()
        {
            Move();
        }

        public virtual void Update()
        {
            
        }

        public virtual void OnAnimationEnterEvent()
        {

        }

        public virtual void OnAnimationExitEvent()
        {

        }

        public virtual void OnAnimationTransitionEvent()
        {

        }

        public void OnTriggerEnter(Collider collider)
        {
            if(stateMachine.player.layerData.IsGroundLayer(collider.gameObject.layer))
            {
                OnContactWithGround(collider);
                return;
            }
        }

        public void OnTriggerExit(Collider collider)
        {
            if (stateMachine.player.layerData.IsGroundLayer(collider.gameObject.layer))
            {
                OnContactWithGroundExit(collider);
                return;
            }
        }
        #endregion

        #region Main Methods

        protected void InitializeData()
        {
            SetBaseRotationData();
        }

        private void ReadMovementInput()
        {
            stateMachine.reusableData.movementInput = Player.Input.playerActions.Movement.ReadValue<Vector2>();
        }

        private void Move()
        {
            if (stateMachine.reusableData.movementInput == Vector2.zero
                || stateMachine.reusableData.movementSpeedModifier == 0f)
            {
                return;
            }

            Vector3 moveDirection = GetMovementInputDirection();

            float targetRotationYAngle = Rotate(moveDirection);

            Vector3 targetRotationDirection = GetTargetDirectionRotation(targetRotationYAngle);

            float speed = GetMovementSpeed();

            Vector3 currentPlayerHorizontalVelocity = GetHorizontalVelocity();

            stateMachine.player.rb.AddForce(targetRotationDirection * speed - currentPlayerHorizontalVelocity, ForceMode.VelocityChange);
        }

        private float Rotate(Vector3 direction)
        {
            float directionAngle = UpdateTargetRotation(direction);

            RotateTowardsTargetRotation();

            return directionAngle;
        }

        private void UpdateTargetRotationData(float targetAngle)
        {
            stateMachine.reusableData.CurrentTargetRotation.y = targetAngle;

            stateMachine.reusableData.DampedTargetRotationPassedTime.y = 0f;
        }
        #endregion

        #region Reuseable Methods
        protected void StartAnimation(int animationHash)
        {
            stateMachine.player.animator.SetBool(animationHash, true);
        }

        protected void StopAnimation(int animationHash)
        {
            stateMachine.player.animator.SetBool(animationHash, false);
        }

        protected virtual void OnContactWithGroundExit(Collider collider)
        {
            
        }

        protected virtual void OnContactWithGround(Collider collider)
        {
            
        }

        protected void SetBaseRotationData()
        {
            stateMachine.reusableData.rotationData = movementData.baseRotationData;

            stateMachine.reusableData.TimeToReachTargetRotation = stateMachine.reusableData.rotationData.targetRotationReachTime;
        }

        protected Vector3 GetMovementInputDirection()
        {
            return new Vector3(stateMachine.reusableData.movementInput.x, 0f, stateMachine.reusableData.movementInput.y);
        }

        protected float GetMovementSpeed(bool shouldConsderSlope = true)
        {
            float movementSpeed = movementData.baseSpeed * stateMachine.reusableData.movementSpeedModifier;

            if (shouldConsderSlope)
            {
                movementSpeed *= stateMachine.reusableData.movementOnSlopeSpeedModifier;
            }

            return movementSpeed;
        }

        protected Vector3 GetHorizontalVelocity()
        {
            Vector3 playerHorizontalVelocity = stateMachine.player.rb.velocity;

            playerHorizontalVelocity.y = 0f;

            return playerHorizontalVelocity;
        }

        protected Vector3 GetVerticalVelocity()
        {
            return new Vector3(0f, stateMachine.player.rb.velocity.y, 0f);
        }

        protected void RotateTowardsTargetRotation()
        {
            float currentYAngle = stateMachine.player.rb.rotation.eulerAngles.y;

            if(currentYAngle== stateMachine.reusableData.CurrentTargetRotation.y)
            {
                return;
            }

            float smoothedYAngle = Mathf.SmoothDampAngle(currentYAngle, stateMachine.reusableData.CurrentTargetRotation.y,
                ref stateMachine.reusableData.DampedTargetRotationCurrentVelocity.y,
                stateMachine.reusableData.TimeToReachTargetRotation.y - stateMachine.reusableData.DampedTargetRotationPassedTime.y); //������ô������������

            stateMachine.reusableData.DampedTargetRotationPassedTime.y += Time.deltaTime;

            Quaternion targetRotation = Quaternion.Euler(0f, smoothedYAngle, 0f);

            stateMachine.player.rb.MoveRotation(targetRotation);
        }

        protected float UpdateTargetRotation(Vector3 direction, bool shouldConsiderCameraRotation = true)
        {
            float directionAngle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;//������ô����������

            if (directionAngle < 0f)
            {
                directionAngle += 360f;
            }

            if(shouldConsiderCameraRotation)
            {
                directionAngle += stateMachine.player.mainCameraTransform.eulerAngles.y;
            }

            if (directionAngle > 360f)
            {
                directionAngle -= 360f;
            }

            if (directionAngle != stateMachine.reusableData.CurrentTargetRotation.y)
            {
                UpdateTargetRotationData(directionAngle);
            }

            return directionAngle;
        }

        protected Vector3 GetTargetDirectionRotation(float targetAngle)
        {
            return Quaternion.Euler(0f, targetAngle, 0f) * Vector3.forward;//������ô??????????
        }

        protected void ResetVelocity()
        {
            stateMachine.player.rb.velocity = Vector3.zero;
        }

        protected virtual void AddInputActionsCallBack()
        {
            Player.Input.playerActions.WalkToggle.started += OnWalkToggleStarted;

            Player.Input.packageActions.OpenPackage.started += OnOpenPackage;
        }

        protected virtual void RemoveInputActionsCallBack()
        {
            Player.Input.playerActions.WalkToggle.started -= OnWalkToggleStarted;

            Player.Input.packageActions.OpenPackage.started -= OnOpenPackage;
        }

        protected void DecelerateHorizontally()
        {
            Vector3 playerHorizontalVelocity = GetHorizontalVelocity();

            stateMachine.player.rb.AddForce(-playerHorizontalVelocity * stateMachine.reusableData.movementDecelerationForce, ForceMode.Acceleration);

            if (playerHorizontalVelocity.magnitude < 0.5f)
            {
                stateMachine.player.rb.velocity = new Vector3(0, 0, 0);
                stateMachine.ChangeState(stateMachine.idlingState);
            }
        }

        protected void DecelerateVertically()
        {
            Vector3 playerVertivalVelocity = GetVerticalVelocity();

            stateMachine.player.rb.AddForce(-playerVertivalVelocity * stateMachine.reusableData.movementDecelerationForce, ForceMode.Acceleration);
        }

        protected bool IsMovingHorizontally(float minimumMagnitude = 0.15f)
        {
            Vector3 playerHorizontalVelocity = GetHorizontalVelocity();

            Vector2 playerHorizontalMovement = new Vector2(playerHorizontalVelocity.x, playerHorizontalVelocity.z);

            return playerHorizontalMovement.magnitude > minimumMagnitude;
        }

        protected bool IsMovingUp(float minimumvelocity = 0.1f)
        {
            return GetVerticalVelocity().y > minimumvelocity;
        }

        protected bool IsMovingDown(float minimumvelocity = 0.1f)
        {
            return GetVerticalVelocity().y < -minimumvelocity;
        }

        protected void ResetVerticalVelocity()
        {
            Vector3 playerHorizontalVelocity = GetHorizontalVelocity();

            stateMachine.player.rb.velocity = playerHorizontalVelocity;
        }
        #endregion

        #region Input Methods
        protected virtual void OnWalkToggleStarted(InputAction.CallbackContext context)
        {
            stateMachine.reusableData.shouldWalk = !stateMachine.reusableData.shouldWalk;
        }

        protected virtual void OnOpenPackage(InputAction.CallbackContext context)
        {
            if (PackageReusableData.instance.isOpenPackage)
            {
                UIManager.instance.ClosePanel(UIConst.packagePanel);
            }
            else
            {
                UIManager.instance.OpenPanel(UIConst.packagePanel);
            }
        }
        #endregion
    }
}
