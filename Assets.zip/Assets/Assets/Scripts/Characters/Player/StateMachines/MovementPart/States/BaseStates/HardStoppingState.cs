using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class HardStoppingState : StoppingState
    {
        public HardStoppingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.hardStopParameterHash);

            stateMachine.reusableData.movementDecelerationForce = movementData.stopData.hardDecelerationForce;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.strongForce;

            Player.Input.playerActions.Movement.Disable();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.hardStopParameterHash);

            Player.Input.playerActions.Movement.Enable();
        }
        #endregion

        #region Reusable Methods
        protected override void OnMove()
        {
            if (stateMachine.reusableData.shouldWalk) return;

            stateMachine.ChangeState(stateMachine.runningState);
        }
        #endregion
    }
}
