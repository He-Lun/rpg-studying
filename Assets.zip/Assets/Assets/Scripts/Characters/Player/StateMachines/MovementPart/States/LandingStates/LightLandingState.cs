using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jenshin
{
    public class LightLandingState : LandingState
    {
        public LightLandingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            stateMachine.reusableData.movementSpeedModifier = 0f;

            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.stationaryForce;

            ResetVelocity();
        }

        public override void Update()
        {
            base.Update();

            if (stateMachine.reusableData.movementInput == Vector2.zero)
            {
                return;
            }

            OnMove();
        }

        public override void OnAnimationTransitionEvent()
        {
            stateMachine.ChangeState(stateMachine.idlingState);


        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            if (!IsMovingHorizontally())
                return;

            ResetVelocity();
        }
        #endregion
    }
}
