using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class HardLandingState : LandingState
    {
        public HardLandingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.hardLandParameterHash);

            Player.Input.playerActions.Movement.Disable();

            stateMachine.reusableData.movementSpeedModifier = 0f;

            ResetVelocity();
        }

        public override void OnAnimationTransitionEvent()
        {
            stateMachine.ChangeState(stateMachine.idlingState);
        }

        public override void OnAnimationExitEvent()
        {
            Player.Input.playerActions.Movement.Enable();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.hardLandParameterHash);

            Player.Input.playerActions.Movement.Enable();
        }

        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            if (!IsMovingHorizontally())
                return;

            ResetVelocity();
        }
        #endregion

        #region Reusable Methods
        protected override void AddInputActionsCallBack()
        {
            base.AddInputActionsCallBack();

            Player.Input.playerActions.Movement.started += OnMovementStarted;
        }

        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
            base.OnMovementCancelled(context);

            Player.Input.playerActions.Movement.started -= OnMovementStarted;
        }

        protected override void OnMove()
        {
            if (stateMachine.reusableData.shouldWalk)
            {
                return;
            }

            stateMachine.ChangeState(stateMachine.runningState);
        }
        #endregion

        #region Input Methods
        protected override void OnJumpStarted(InputAction.CallbackContext context)
        {
        }

        private void OnMovementStarted(InputAction.CallbackContext context)
        {
            OnMove();
        }
        #endregion
    }
}
