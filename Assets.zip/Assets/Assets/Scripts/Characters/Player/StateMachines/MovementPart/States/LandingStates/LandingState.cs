using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class LandingState : PlayerGroundedState
    {
        public LandingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
        }

        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.landingParameterHash);
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.landingParameterHash);
        }

        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {

        }
        #endregion
    }
}
