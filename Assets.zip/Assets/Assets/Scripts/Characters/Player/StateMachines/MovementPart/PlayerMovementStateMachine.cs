namespace jenshin
{
    public class PlayerMovementStateMachine : StateMachine
    {
        //ֻ������
        public PlayerReusableData reusableData { get; }

        public Player player { get; }

        public IdlingState idlingState { get; }

        public DashingState dashingState { get; }

        public WalkingState walkingState { get; }

        public RunningState runningState { get; }

        public SprintingState sprintingState { get; }

        public LightStoppingState lightStoppingState { get; }

        public MediumStoppingState mediumStoppingState { get; }

        public HardStoppingState hardStoppingState { get; }

        public JumpState jumpState { get; }

        public FallingState fallingState { get; }

        public LightLandingState lightLandingState { get; }

        public RollingState rollingState { get; }

        public HardLandingState hardLandingState { get; }

        //���캯��
        public PlayerMovementStateMachine(Player player)
        {
            this.player = player;

            reusableData = new PlayerReusableData();
            dashingState = new DashingState(this);
            idlingState = new IdlingState(this);
            walkingState = new WalkingState(this);
            runningState = new RunningState(this);
            sprintingState = new SprintingState(this);
            lightStoppingState = new LightStoppingState(this);
            mediumStoppingState = new MediumStoppingState(this);
            hardStoppingState = new HardStoppingState(this);
            jumpState = new JumpState(this);
            fallingState = new FallingState(this);
            lightLandingState = new LightLandingState(this);
            rollingState = new RollingState(this);
            hardLandingState = new HardLandingState(this);
        }
    }
}
