using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class SprintingState : PlayerMovingState
    {
        private PlayerSprintData sprintData;
        private bool keepSprinting;
        private bool shouldResetSprintState;
        private float startTime;
        public SprintingState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            sprintData = movementData.sprintData;
        }

        #region IState Methods
        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.sprintParameterHash);

            stateMachine.reusableData.movementSpeedModifier = sprintData.speedModifier;
            stateMachine.reusableData.currentJumpForce = airborneData.jumpData.strongForce;

            shouldResetSprintState = true;

            startTime = Time.time;
        }

        public override void Update()
        {
            base.Update();

            if (keepSprinting) return;

            if(Time.time<startTime+sprintData.sprintToRunTime)
            {
                return;
            }

            StopSprintint();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.sprintParameterHash);

            if (shouldResetSprintState)
            {
                keepSprinting = false;

                stateMachine.reusableData.shouldSprint = false;
            }
        }
        #endregion

        private void StopSprintint()
        {
            if (stateMachine.reusableData.movementInput == Vector2.zero)
            {
                stateMachine.ChangeState(stateMachine.idlingState);

                return;
            }

            stateMachine.ChangeState(stateMachine.runningState);
        }

        #region Reusable Methods
        protected override void AddInputActionsCallBack()
        {
            base.AddInputActionsCallBack();

            Player.Input.playerActions.Sprint.performed += OnSprintPerformed;
        }

        protected override void RemoveInputActionsCallBack()
        {
            base.RemoveInputActionsCallBack();

            Player.Input.playerActions.Sprint.performed -= OnSprintPerformed;
        }

        protected override void OnFall()
        {
            shouldResetSprintState = false;

            base.OnFall();
        }
        #endregion


        #region Input Methods
        protected override void OnMovementCancelled(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.hardStoppingState);
        }

        protected override void OnJumpStarted(InputAction.CallbackContext context)
        {
            shouldResetSprintState = true;

            base.OnJumpStarted(context);
        }

        private void OnSprintPerformed(InputAction.CallbackContext context)
        {
            keepSprinting = true;

            stateMachine.reusableData.shouldSprint = true;
        }
        #endregion
    }
}
