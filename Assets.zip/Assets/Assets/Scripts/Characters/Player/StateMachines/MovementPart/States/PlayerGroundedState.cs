using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class PlayerGroundedState : MovementState
    {
        private SlopeData slopeData;

        public PlayerGroundedState(PlayerMovementStateMachine playerMovementStateMachine) : base(playerMovementStateMachine)
        {
            slopeData = stateMachine.player.colliderUnity.slopeData;
        }

        #region IState Methods
        public override void PhysicsUpdate()
        {
            base.PhysicsUpdate();

            Float();
        }

        public override void Enter()
        {
            base.Enter();

            StartAnimation(stateMachine.player.animationData.groundedParameterHash);

            UpdateShouldSprintState();
        }

        public override void Exit()
        {
            base.Exit();

            StopAnimation(stateMachine.player.animationData.groundedParameterHash);
        }
        #endregion

        #region Main Methods
        private void UpdateShouldSprintState()
        {
            if (!stateMachine.reusableData.shouldSprint)
            {
                return;
            }

            if (stateMachine.reusableData.movementInput != Vector2.zero)
            {
                return;
            }

            stateMachine.reusableData.shouldSprint = false;
        }

        private void Float()
        {
            Vector3 capsuleColliderCenterInWorldSpace = stateMachine.player.colliderUnity.capsuleColliderData.collider.bounds.center;

            Ray downWardsRayFromCapsuleCenter = new Ray(capsuleColliderCenterInWorldSpace, Vector3.down);

            if (Physics.Raycast(downWardsRayFromCapsuleCenter, out RaycastHit hit, slopeData.floatRayDistance,
                stateMachine.player.layerData.groundLayer, QueryTriggerInteraction.Ignore))
            {
                float groundAngle = Vector3.Angle(hit.normal, -downWardsRayFromCapsuleCenter.direction);

                float slopeSpeedModifier = SetSlopeSpeedModifierOnAngle(groundAngle);

                if (slopeSpeedModifier == 0f)
                {
                    return;
                }

                float distanceToFloatingPoint = stateMachine.player.colliderUnity.capsuleColliderData.colliderCenterInLocalSpace.y
                    * stateMachine.player.transform.localScale.y - hit.distance;

                if (distanceToFloatingPoint == 0f) return;

                float amountToLift = distanceToFloatingPoint * slopeData.stepReachForce - GetVerticalVelocity().y; 

                Vector3 liftForce = new Vector3(0f, amountToLift, 0f);

                stateMachine.player.rb.AddForce(liftForce, ForceMode.VelocityChange);
            }
        }

        private float SetSlopeSpeedModifierOnAngle(float angle)
        {
            float slopeSpeedModifier = movementData.slopeSpeedAngle.Evaluate(angle);

            stateMachine.reusableData.movementOnSlopeSpeedModifier = slopeSpeedModifier;

            return slopeSpeedModifier;
        }

        private bool IsThereGroundUnderneath()
        {
            BoxCollider groudCheckCollider = stateMachine.player.colliderUnity.triggerColliderData.groundCheckCollider;

            Vector3 groundColliderCenterInWorldSpace = groudCheckCollider.bounds.center;

            Collider[] overlappedGroundColliders = Physics.OverlapBox(groundColliderCenterInWorldSpace, groudCheckCollider.bounds.extents
                , groudCheckCollider.transform.rotation, stateMachine.player.layerData.groundLayer, QueryTriggerInteraction.Ignore);

            return overlappedGroundColliders.Length > 0f;
        }
        #endregion

        #region Reusable Methods
        protected override void AddInputActionsCallBack()
        {
            base.AddInputActionsCallBack();

            Player.Input.playerActions.Movement.canceled += OnMovementCancelled;

            Player.Input.playerActions.Dash.started += OnDashStarted;

            Player.Input.playerActions.Jump.started += OnJumpStarted;
        }

        protected override void RemoveInputActionsCallBack()
        {
            base.RemoveInputActionsCallBack();

            Player.Input.playerActions.Movement.canceled -= OnMovementCancelled;

            Player.Input.playerActions.Dash.started -= OnDashStarted;

            Player.Input.playerActions.Jump.started -= OnJumpStarted;
        }
        protected virtual void OnMove()
        {
            if(stateMachine.reusableData.shouldSprint)
            {
                stateMachine.ChangeState(stateMachine.sprintingState);
                return;
            }

            if (stateMachine.reusableData.shouldWalk)
            {
                stateMachine.ChangeState(stateMachine.walkingState);
                return;
            }

            stateMachine.ChangeState(stateMachine.runningState);
        }

        protected override void OnContactWithGroundExit(Collider collider)
        {
            base.OnContactWithGroundExit(collider);

            if(IsThereGroundUnderneath())
            {
                return;
            }

            Vector3 capsuleColliderCenterInWorldSpace = stateMachine.player.colliderUnity.capsuleColliderData.collider.bounds.center;

            Ray downwardsRayFromCapsuleBottom = new Ray(capsuleColliderCenterInWorldSpace-stateMachine.player.colliderUnity.capsuleColliderData.colliderVerticalExtents
                , Vector3.down);

            if(!Physics.Raycast(downwardsRayFromCapsuleBottom,out _,movementData.groundToFallRayDistance,stateMachine.player.layerData.groundLayer))
            {
                OnFall();
            }
        }

        protected virtual void OnFall()
        {
            stateMachine.ChangeState(stateMachine.fallingState);
        }
        #endregion

        #region Input Methods
        protected virtual void OnMovementCancelled(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.idlingState);
        }

        protected virtual void OnDashStarted(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.dashingState);
        }

        protected virtual void OnJumpStarted(InputAction.CallbackContext context)
        {
            stateMachine.ChangeState(stateMachine.jumpState);
        }
        #endregion
    }
}
