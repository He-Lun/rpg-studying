using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace jenshin
{
    public class PlayerInput : MonoBehaviour
    {
        public PlayerInputActions InputActions { get; private set; }
        public PlayerInputActions.PlayerActions playerActions { get; private set; }
        public PlayerInputActions.PackageActions packageActions { get; private set; }
        public PlayerInputActions.InteractActions interactActions { get; private set; }

        private void Awake()
        {
            InputActions = new PlayerInputActions();

            playerActions = InputActions.Player;

            packageActions = InputActions.Package;

            interactActions = InputActions.Interact;
        }

        private void OnEnable()
        {
            InputActions.Enable();
        }

        private void OnDisable()
        {
            InputActions.Disable();
        }

        public void DisableActionFor(InputAction action,float seconds)
        {
            StartCoroutine(DisableAction(action, seconds));
        }

        private IEnumerator DisableAction(InputAction action, float seconds)
        {
            action.Disable();

            yield return new WaitForSeconds(seconds);

            action.Enable();
        }
    }
}
